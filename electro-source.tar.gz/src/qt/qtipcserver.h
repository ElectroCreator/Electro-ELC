#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define Electro-Qt message queue name
#define BITCOINURI_QUEUE_NAME "ElectroURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
